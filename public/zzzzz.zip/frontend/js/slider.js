//
// $(window).scroll(function(){
//     var scrolled= $('.js-fixed').offset().top,
//         docViewTop = $(window).scrollTop();
//     if(scrolled<=docViewTop) {
//         $('.js-fixed_line').addClass('weee');
//     }
//     else {
//         $('.js-fixed_line').removeClass('weee');
//     }
//
// });